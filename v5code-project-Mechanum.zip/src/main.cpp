/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Work                                             */
/*    Created:      Fri Mar 11 2022                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// BR                   motor         6               
// FL                   motor         4               
// FR                   motor         7               
// BL                   motor         11              
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  //setting up motors (FLF - front left forward)
  motor FLF = motor(PORT4, ratio18_1, false);
  motor FRF = motor(PORT7, ratio18_1, true);
  motor BLF = motor(PORT11, ratio18_1, false);
  motor BRF = motor(PORT6, ratio18_1, true);

  motor FLB = motor(PORT4, ratio18_1, true);
  motor FRB = motor(PORT7, ratio18_1, false);
  motor BLB = motor(PORT11, ratio18_1, true);
  motor BRB = motor(PORT6, ratio18_1, false);

  // Setting up drive bases
  motor_group drive_front_back(FLF, FRF, BLF, BRF);

  motor_group r_spin(FL, FR, BL, BR);

  /*
  Exemplar:
  motor_group left(backleft, frontleft);
  motor_group right(frontright, backright);
  motor_group all(frontleft, frontright, backleft, backright);
  */

  /*
  Exemplar #2:
  Controller1.Axis3.position() < 0
  */
  while (true){
    if(Controller1.Axis3.position() > 0){
      drive_front_back.spin(forward);
    }
    
    if(Controller1.Axis3.position() < 0){
      drive_front_back.spin(reverse);
    }
  }
}